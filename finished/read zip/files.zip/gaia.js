/*
Created by Gavin Delphia 2007 - 2011
Version 10521132011
Not compatible with previous versions
*/

var xarc = 0; //Used to test if the application is still in a archive

// Array Prototypes //
[].indexOf || (Array.prototype.indexOf = function(v,n){
	n = (n==null) ? 0 : n; var m = this.length;
	for(var i = n; i < m; i++)
	if(this[i] == v)
	return i;
	return -1;
});

if(typeof Array.prototype.copy === 'undefined'){
	Array.prototype.copy = function(){
		var a = [], i = this.length;
		while(i--){
			a[i] = typeof this[i].copy !== 'undefined' ? this[i].copy() : this[i];
		}
		return a;
	};
}

Array.prototype.shuffle = function(b){
	var i = this.length, j, t;
	while(i){
		j = Math.floor((i--) * Math.random());
		t = b && typeof this[i].shuffle !== 'undefined' ? this[i].shuffle() : this[i];
		this[i] = this[j];
		this[j] = t;
	}
	return this;
};

Array.prototype.unique = function(b){
	var a = [], i, l = this.length;
	for(var i = 0; i < l; i++){
		if(a.indexOf(this[i], 0, b) < 0){
			a.push(this[i]);
		}
	}
	return a;
};

Array.prototype.remove = function(b){
	this.splice(b, 1);
	return this;
};

// File System //
var XS = {
	temp:new Array(),
	xmlhttp:new ActiveXObject("Microsoft.XMLHttp"),
	stream:new ActiveXObject("ADODB.Stream"),
	fso:new ActiveXObject("Scripting.FileSystemObject"),
	net:new ActiveXObject("WScript.Network"),
	shell:new ActiveXObject("WScript.Shell"),
	file:function(fileName, action, data){
		if (XS.fso.FileExists(fileName)){
			if (action == 'exist'){
				return true;
			}
			else if (action == 'open'){
				XS.temp[0] = XS.fso.GetFile(fileName).OpenAsTextStream(1, 0);
				XS.temp[1] = XS.temp[0].ReadAll();
				XS.temp[0].close();
				return XS.temp[1];
			}
			else if (action == 'writeline'){
				XS.temp[0] = XS.fso.OpenTextFile(fileName, 8, 1, -2);
				XS.temp[0].writeline(data);
				XS.temp[0].Close();
			}
			else if (action == 'create'){
				XS.temp[0] = XS.fso.createTextFile(fileName);
				XS.temp[0].write(data); 
				XS.temp[0].close();
			}
			else if (action == 'delete'){
				XS.fso.DeleteFile(fileName); 
			}
			else if (action == 'size'){
				return XS.fso.GetFile(fileName).Size;
			}
			else if (action == 'basename'){
				return XS.fso.GetBaseName(fileName);
			}
			else if (action == 'extension'){
				return XS.fso.GetExtensionName(fileName);
			}
			else if (action == 'name'){
				return XS.fso.GetFileName(fileName);
			}
			else if (action == 'move' && XS.Folder(data, 'exist')){
				XS.fso.MoveFile(fileName, data);		
			}
			else if (action == 'copy' && XS.Folder(data, 'exist')){
				XS.fso.CopyFile(fileName, data);	
			}
			return false;
		}else if (action == 'create'){
			XS.temp[0] = XS.fso.createTextFile(fileName);
			XS.temp[0].write(data); 
			XS.temp[0].close();
		}else if (action == 'download'){
			XS.xmlhttp.Open("GET", fileName, false);
			XS.xmlhttp.Send();
			XS.stream.open();
			XS.stream.type = 1;
			XS.stream.write(XS.xmlhttp.responseBody);
			XS.stream.position = 0;
			if (XS.fso.fileExists(data)){
				XS.fso.deleteFile(data);
			}
			XS.stream.saveToFile(data);
			XS.stream.close();
			XS.fso = XS.stream = XS.xmlhttp = null;
			return data;
		}else{
			return false;
		}
	},
	folder:function(fileName, action, data){
		if (XS.fso.FolderExists(fileName)){
			if (action == 'exist'){
				return true;
			}
			else if (action == 'getfiles'){
				XS.temp[0] = XS.fso.GetFolder(fileName);
				XS.temp[1] = new Array();
				XS.temp[2] = -1;
				for(XS.temp[3] = new Enumerator(XS.temp[0].Files);!XS.temp[3].atEnd();XS.temp[3].moveNext()){
					XS.temp[2]++;
					XS.temp[1][XS.temp[2]] = XS.temp[3].item();
				}
				return XS.temp[1];
			}
			else if (action == 'delete'){
				XS.fso.DeleteFolder(fileName);
			}
			else if (action == 'move' && XS.Folder(data, 'exist')){
				XS.fso.MoveFolder(fileName, data);
			}
			else if (action == 'copy' && XS.Folder(data, 'exist')){
				XS.fso.CopyFolder(fileName, data);	
			}
			else if (action == 'search'){
				var xscan = xscan.splice(0, 0);
				XS.temp[0] = (data.lastIndexOf(".") > -1) ? data.slice(0, data.lastIndexOf(".")) : (data.length > 0) ? data.toLowerCase() : "*";
				XS.temp[1] = (data.lastIndexOf(".") > -1) ? data.slice(data.lastIndexOf(".") + 1).toLowerCase() : "*"; 
				if(fileName.length > 0 && XS.fso.FolderExists(fileName)){
					XS.temp[2] = new Enumerator(XS.fso.GetFolder(fileName).Files);
					for(var i = 0; !XS.temp[2].atEnd(); XS.temp[2].moveNext()){
						if(XS.temp[0] == "*" ||  XS.temp[2].item().name.slice(0,XS.temp[2].item().name.lastIndexOf(".")).toLowerCase().indexOf(XS.temp[0]) > -1){
							if(XS.temp[1] == "*" || XS.temp[2].item().name.slice(XS.temp[2].item().name.lastIndexOf(".") + 1).toLowerCase().indexOf(XS.temp[1]) > -1){
								xscan[i] = XS.temp[2].item().name;
								i++;
							}
						}
					}
				}
				return xscan;
			}
			return false;
		}
		else if (action == 'create'){
			XS.fso.createFolder(fileName);
			return fileName;		
		}
		else{
			return false;
		}
	},
	currentPath:function(){
		return XS.fso.GetFolder(".").Path;
	}
};


// Network Functions //
var XN = {
	getName:function(mode){
		if (mode == 'computer'){
			return XS.net.ComputerName;
		}
		else if (mode == 'user'){
			return XS.net.UserName;
		}
		else if (mode == 'domain'){
			return XS.net.DomainName;
		}
		else if (mode == 'mac'){
			var objWMIService = GetObject("winmgmts:\\\\.\\root\\cimv2");
			var e = new Enumerator(objWMIService.ExecQuery("Select * from Win32_NetworkAdapter", "WQL", 48));
			for (; !e.atEnd(); e.moveNext()){	
				objItem = e.item();
				if (objItem.MACAddress != null){
					return objItem.MACAddress;
					break;
				}
			}
		}
	}
};


// Shell Functions //
var XWS = {
	launch:function(command){
		XS.shell.Run(command, 0);
	},
	reg:function(keyName, action, data){
		if (action == 'read'){
			return XS.shell.RegRead(keyName);
		}
		else if (action == 'delete'){
			return XS.shell.RegDelete(keyName);
		}
		else if (action == 'write'){
			XS.shell.RegWrite(keyName, data);
			XWS.Reg(keyName, 'read');
		}
	},
	sendKey:function(key){
		XS.shell.SendKeys(key);
	}
};

// Utility Functions //
var XU = {
	centerElement:function(eleId, mode, xOffset, yOffset){
		xOffset = xOffset || 0;
		yOffset = yOffset || 0;
		if (mode == 'v' || mode == 'b'){
			XU.el(eleId).style.top = Math.round(yOffset + (parseInt(document.body.offsetHeight) / 2) - (XU.el(eleId).offsetHeight / 2)) + yOffset;
		}
		if (mode == 'h' || mode == 'b'){
			XU.el(eleId).style.left = Math.round(xOffset + (parseInt(document.body.offsetWidth) / 2) - (XU.el(eleId).offsetWidth / 2)) + xOffset;
		}
	},
	DFR:function(eleId, distance){
		XU.el(eleId).style.left = Math.round(parseInt(document.body.offsetWidth) - (XU.el(eleId).offsetWidth + distance));
	},
	DFB:function(eleId, distance){
		XU.el(eleId).style.top = Math.round(parseInt(document.body.offsetHeight) - (XU.el(eleId).offsetHeight + distance));
	},
	resizeWindow:function(params){
		if (params.fullscreen){
			params.height = parseInt(screen.height);
			params.width = parseInt(screen.width);
		}
		if (params.centered){
			self.moveTo(parseInt(screen.width) / 2 - (params.width / 2), parseInt(screen.height) / 2 - (params.height / 2));
		}
		try{
			window.resizeTo(params.width, params.height);
		}catch(e){
			XU.resizeWindow(params);
		}
	},
	moveWindow:function(x, y){
		if (x == "c"){
			x = parseInt(screen.width) / 2 - (document.body.offsetWidth / 2);
		}
		if (y == "c"){
			y = parseInt(screen.height) / 2 - (document.body.offsetHeight / 2);
		}
		self.moveTo(x, y);
	},
	isArray:function(eleObj){
		return (eleObj.constructor.toString().indexOf('Array') == -1) ? false : true;
	},
	drawRepeat:function(string, amt){
		var temp = '';
		for (var x = 0; x < amt; x++){
			temp += string;
		}
		return temp;
	},
	el:function(eleId){
		return document.getElementById(eleId);
	},
	createShortcut:function(name, path, icon, description){ //scut is not a param
		if (!XS.file(XS.shell.SpecialFolders('Desktop') + '\\' + name + '.lnk', 'exist')){
			var scut = XS.shell.CreateShortcut(XS.shell.SpecialFolders('Desktop') + '\\' + name + '.lnk');
			scut.TargetPath = XS.shell.CurrentDirectory + '\\' + path;
			scut.WindowStyle = 1;
			scut.IconLocation = XS.shell.CurrentDirectory + '\\' + icon;
			scut.Description = description;
			scut.WorkingDirectory = XS.CurrentPath();
			scut.Save();
		}
	},
	changeClass:function(eleId, className){
		XU.el(eleId).className = className;
	},
	scroll:function(eleId){
		XU.el(eleId).scrollTop = XU.el(it).scrollHeight;
	},
	hide:function(eleId){
		XU.el(eleId).style.display = 'none';
	},
	show:function(eleId){
		XU.el(eleId).style.display = 'block';
	},
	intoBody:function(data){
		var container = document.createElement("SPAN");
		container.innerHTML = data;
		document.body.appendChild(container);
	}
};



var XM = {
	trueButton: "Accept",
	falseButton: "Cancel",
	hoverColor: "#0099ff",
	defaultColor: "silver",
	defaultSpace: 30,
	alert:function(params){
		params.left = params.left || 'center';
		params.top = params.top || 'center';
		params.width = params.width || 300;
		XM.private.universal(params);
		XM.get('buttons', XM.private.seed).innerHTML = XM.private.button(XM.private.seed, true);
		return XM.private.seed;
	},
	static:function(params){
		XM.private.universal(params);
		XM.get('buttons', XM.private.seed).innerHTML = "";
		return XM.private.seed;
	},
	confirm:function(params){
		params.left = params.left || 'center';
		params.top = params.top || 'center';
		params.width = params.width || 300;
		XM.private.universal(params);
		XM.get('buttons', XM.private.seed).innerHTML = XM.private.button(XM.private.seed, true) + XU.drawRepeat('&nbsp;', XM.defaultSpace) + XM.private.button(XM.private.seed, false);
		return XM.private.seed;
	},
	get:function(field, seed){
		return document.getElementById('xm_' + field + seed);
	},
	destroy:function(seed){
		var ele = XU.el('xm_window' + seed);
		ele.parentNode.removeChild(ele);
	},
	screenCover:function(state){
		xm_screen.style.display = (state) ? "block" : "none";
	},
	setBody:function(seed, data){
		XM.get('body', seed).innerHTML = '<br>' + data;
	},
	setTitle:function(seed, data){
		XM.get('title', seed).innerHTML = data;
	},
	setSize:function(seed, params){
		XM.private.sizes(seed, params);
	},
	setPosition:function(seed, params){
		XM.private.positions(seed, params);
	},
	hide:function(seed){
		XM.get('window', seed).style.display = "none";
	},
	show:function(seed){
		XM.get('window', seed).style.display = "block";
	},
	private:{
		seed:-1,
		iniVar:false,
		ini:function(){
		try{
			var ele = XU.el('xm_container');
			ele.parentNode.removeChild(ele);
		}catch(e){}
			document.body.innerHTML += '<div id="xm_screen" style="background-color:white;cursor:default;filter:alpha(opacity = 20);opacity:0.2;position:absolute;z-index:19998;left:0;top:0;width:100%;height:100%;border:none;zoom:1;display:none;"></div>';
			XM.private.iniVar = true;
		},
		universal:function(params){
			XM.private.draw();
			XM.screenCover(params.screen);
			XM.get('title', XM.private.seed).innerHTML = (params.title) ? params.title : "";
			XM.get('body', XM.private.seed).innerHTML = (params.body) ? "<br>" + params.body : "";
			XM.get('window', XM.private.seed).style.display = 'block';
			XM.private.sizes(XM.private.seed, params);
			XM.private.positions(XM.private.seed, params);
			XM.get('window', XM.private.seed).onmouseover = function(){
				var source = event.srcElement;
				if (source.seed){
					source.style.color = XM.hoverColor;
				}
			}
			XM.get('window', XM.private.seed).onmouseout = function(){
				var source = event.srcElement;
				if (source.seed){
					source.style.color = XM.defaultColor;
				}
			}
			XM.get('window', XM.private.seed).onclick = function(){
				var source = event.srcElement;
				if (source.seed){
					XM.private.callback(source.result, params, source.seed);
				}
			}
		},
		sizes:function(seed, params){
			if (params.width){
				XM.get('window', seed).style.width = params.width;
			}
			if (params.height){
				XM.get('window', seed).style.height = params.height;
			}
		},
		positions:function(seed, params){
			if (params.centered){
				params.top = 'center';
				params.left = 'center';
			}
			if (params.top == 'center'){
				XU.centerElement('xm_window' + seed, 'v');
			}else if (params.top){
				XM.get('window', seed).style.top = params.top;
			}
			if (params.left == 'center'){
				XU.centerElement('xm_window' + seed, 'h');
			}else if (params.left){
				XM.get('window', seed).style.left = params.left;
			}
		},
		callback:function(result, params, seed){
			var usercall = params.callback;
			if (usercall){
				usercall(result);
			}
			XM.screenCover(false);
			XM.destroy(seed);
		},
		button:function(seed, type){
			var btnText = (type == true) ? XM.trueButton : XM.falseButton;
			return '<span result=' + type + ' style="cursor:hand;" seed=' + seed + ' id="btn' + type + seed + '">' + btnText + '</span>';
		},
		draw:function(){
			XM.private.seed++;
			if (!XM.private.iniVar){
				XM.private.ini();
			}
			var container = document.createElement("SPAN");
			container.innerHTML = '<table style="position:absolute;top:0;left:0;display:none;z-index:19999;" cellpadding=0 cellspacing=0 id="xm_window'+XM.private.seed+'"><tr><td style="overflow:hidden;background:url(\'xres/WindowTopLeft.png\') repeat scroll 0% 0% transparent;width:15px;height:32px;">&nbsp;</td><td style="overflow:hidden;background:url(\'xres/WindowTopCenter.png\') repeat scroll 0% 0% transparent;color:'+XM.defaultColor+';" id="xm_title'+XM.private.seed+'">&nbsp;</td><td style="overflow:hidden;background:url(\'xres/WindowTopRight.png\') repeat scroll 0% 0% transparent;width:15px;">&nbsp;</td></tr><tr><td style="overflow:hidden;background:url(\'xres/WindowCenterLeft.png\') repeat scroll 0% 0% transparent;">&nbsp;</td><td style="overflow:hidden;background:url(\'xres/WindowCenter.png\') repeat scroll 0% 0% transparent;text-align:left;color:'+XM.defaultColor+';overflow-x:auto;word-wrap:break-word;" id="xm_body'+XM.private.seed+'">&nbsp;</td><td style="overflow:hidden;background:url(\'xres/WindowCenterRight.png\') repeat scroll 0% 0% transparent;">&nbsp;</td></tr><tr><td style="overflow:hidden;background:url(\'xres/WindowBottomLeft.png\') repeat scroll 0% 0% transparent;height:39px;">&nbsp;</td><td style="overflow:hidden;background:url(\'xres/WindowBottomCenter.png\') repeat scroll 0% 0% transparent;height:39px;color:'+XM.defaultColor+';text-align:center;" id="xm_buttons'+XM.private.seed+'">&nbsp;</td><td style="overflow:hidden;background:url(\'xres/WindowBottomRight.png\') repeat scroll 0% 0% transparent;height:39px;">&nbsp;</td></tr></table>';
			document.body.appendChild(container);
		}
	}
};


// Save Data //
var XDS = {
	save_vars:new Array(),
	temp:new Array(3),
	ini:function(){
		if (XDS.save_vars.length == 0){
			XM.alert({title:'XDS', body:'You have not defined the array <font color="red">XDS.save_vars</font>'});
		}
	},
	save:function(it){
		XDS.temp[0] = "";
		XDS.temp[1] = 0;
		for (var i = 0; i <= XDS.save_vars.length - 1; i++){
			if (XU.isArray(window[XDS.save_vars[i]])){
				for (a = 0; a <= window[XDS.save_vars[i]].length - 1; a++){
					if (XU.isArray(window[XDS.save_vars[i]][a])){
						XDS.temp[1] = 1;
					}
				}
				if (XDS.temp[1] == 0){
					XDS.temp[0] += "!${a}" + XDS.save_vars[i] + "@#" + window[XDS.save_vars[i]].join('!~');
				}else{
					XDS.temp[0] += "!${m}" + XDS.save_vars[i] + "@#";
					for (var a = 0; a <= window[XDS.save_vars[i]].length - 1; a++){
						if (XU.isArray(window[XDS.save_vars[i]][a])){
							XDS.temp[0] += window[XDS.save_vars[i]][a].join('!~') + "$@";
						}else{
							XDS.temp[0] += window[XDS.save_vars[i]][a] + "$@";
						}
					}
				}
			}else{
				XDS.temp[0] += "!${s}" + XDS.save_vars[i] + "@#" + window[XDS.save_vars[i]];
			}
		}
		XS.file(it, 'create', XDS.temp[0]);
	},
	load:function(it){
		XDS.temp[1] = XDS.temp[2] = '';
		XDS.temp[0] = XS.file(it, 'open').split('!$');
		for (var a = 1; a <= XDS.temp[0].length - 1; a++){
			XDS.temp[0][a] = XDS.temp[0][a].split('}');
		}
		for (var a = 1; a <= XDS.temp[0].length - 1; a++){
			if (XDS.temp[0][a][0] == '{s'){
				XDS.temp[1] = XDS.temp[0][a][1].split('@#');
				XDS.temp[2] += "" + XDS.temp[1][0] + "=";
				if (Math.round(XDS.temp[1][1] * 1) == XDS.temp[1][1] && isNaN(XDS.temp[1][1])){
					XDS.temp[2] += XDS.temp[1][1] + ";";
				}else{
					XDS.temp[2] += "'" + XDS.temp[1][1] + "';";
				}
			}
			else if (XDS.temp[0][a][0] == '{a'){ 
				XDS.temp[1] = XDS.temp[0][a][1].split('@#');
				XDS.temp[2] += "" + XDS.temp[1][0] + "=new Array(";
				XDS.temp[1][1] = XDS.temp[1][1].split('!~');
				for (var c = 0; c <= XDS.temp[1][1].length - 1; c++){
					if (Math.round(XDS.temp[1][1][c] * 1) == XDS.temp[1][1][c] && isNaN(XDS.temp[1][1][c])){
						if (c >= XDS.temp[1][1].length - 1){
							XDS.temp[2] += XDS.temp[1][1][c];
						}else{
							XDS.temp[2] += XDS.temp[1][1][c] + ",";
						}
					}else{
						if (c >= XDS.temp[1][1].length - 1){
							XDS.temp[2] += "'" + XDS.temp[1][1][c] + "'";
						}else{
							XDS.temp[2] += "'" + XDS.temp[1][1][c] + "',";
						}
					}
				}
				XDS.temp[2] += ");"
			}
			else if (XDS.temp[0][a][0] == '{m'){
				XDS.temp[1] = XDS.temp[0][a][1].split('@#');
				XDS.temp[2] += "" + XDS.temp[1][0] + "=new Array(";
				XDS.temp[1][1] = XDS.temp[1][1].split('$@');
				XDS.temp[1][1].pop();
				for (var d = 0; d <= XDS.temp[1][1].length - 1; d++){
					XDS.temp[1][1][d] = XDS.temp[1][1][d].split('!~');
					if (XDS.temp[1][1][d].length != 1){
						XDS.temp[2] += "new Array(";
					}
					for (var c = 0; c <= XDS.temp[1][1][d].length - 1; c++){
						if (Math.round(XDS.temp[1][1][d][c] * 1) == XDS.temp[1][1][d][c] && isNaN(XDS.temp[1][1][d][c])){
							if (c >= XDS.temp[1][1][d].length - 1){
								XDS.temp[2] += XDS.temp[1][1][d][c];
							}else{
								XDS.temp[2] += XDS.temp[1][1][d][c] + ",";
							}
						}else{
							if (c >= XDS.temp[1][1][d].length - 1){
								XDS.temp[2] += "'" + XDS.temp[1][1][d][c] + "'";
							}else{
								XDS.temp[2] += "'" + XDS.temp[1][1][d][c] + "',";
							}
						}
					}
					if (XDS.temp[1][1][d].length != 1){
						if (d >= XDS.temp[1][1].length - 1){
							XDS.temp[2] += ")";
						}else{
							XDS.temp[2] += "),";
						}
					}else{
						if (d >= XDS.temp[1][1].length - 1){
							XDS.temp[2] += "";
						}else{
							XDS.temp[2] += ",";
						}
					}
				}
				XDS.temp[2] += ");"
			}
		}
		eval(XDS.temp[2]);
	}
};


//Threads
var Threads = {
	active:[],
	inactive:[],
	add:function(data){
		Threads.active.push(data);
	},
	read:function(){
		if (Threads.active[0]){
			Threads.inactive.push(Threads.active[0]);
			return Threads.active.shift();
		}
	},
	purge:function(){
		Threads.active = [];
		Threads.inactive = [];
	},
	status:function(){
		return [Threads.active.length, Threads.inactive.length];
	}
};


//Network Communication
var XCIP = {
	uname:XN.getName('user'),
	timer:0,
	queue:new Array(),
	data:new Array(),
	ini:function(it){
		if (it == 1){
			XCIP.purge();
		}
		XWS.launch('ipmsg.bat');
		XCIP.queue[2] = new Array();
		XCIP.data[0] = XCIP.uname;
		XCIP.data[1] = 'localhost';
		XCIP.data[2] = document.title;
		//setTimeout("XCIP.Connect(2,'localhost')",1000); //remove line its for testing
	},
	connect:function(it,it2){
		XCIP.data[3] = XS.file('ip.txt', 'open');
		if (!it){
			XM.alert({title:'Connection - IP Address/Computer Name', body:'<br><center>' + XCIP.data[3] + '- ' + XCIP.data[0] + '<br><br><input type="textarea" id="xcipmsgbox" style="border:1 solid white;background-Color:black;color:white;"> <input type="button" value="Connect" style="color:white;background-Color:black;border:1 solid white;height:20;" onclick="XCIP.Connect(1)"></center>'});
			xcipmsgbox.focus();
		}else if (it == 1){
			if (xcipmsgbox.value){
				XCIP.data[1] = xcipmsgbox.value;
			}
			document.title = XCIP.data[2] + ' >> ' + XCIP.data[0] + '@' + XCIP.data[3] + ' >> ' + XCIP.data[1];
			XCIP.timer = setInterval("XCIP.In()", 1000);
			try{
				App.pingServer();
			}catch(e){
				alert('App.pingServer() in XCIP does not exist. This is the function called immediatly after a ip address is entered');
			}
		}else if (it == 2){
			XCIP.data[1] = it2;
			document.title = XCIP.data[2] + ' >> ' + XCIP.data[0] + '@' + XCIP.data[3] + ' >> ' + XCIP.data[1];
			XCIP.timer = setInterval("XCIP.msgIn()", 1000);
		}
	},
	disconnect:function(){
		clearInterval(XCIP.timer);
	},
	purge:function(){
		XS.file('C:\\Users\\' + XCIP.uname + '\\Documents\\ipmsg.log', 'delete');
	},
	clean:function(){
		//XS.file('ip.txt','delete');
		XWS.launch('cleanup.bat');
		window.close();
	},
	msgOut:function(it, it2){
		if (it && it2){
			XWS.launch('ipmsg.exe /MSG /LOG ' + it + ' ' + it2);
		}
	},
	msgIn:function(){
		XCIP.queue[0] = [];
		XCIP.queue[1] = [];
		XCIP.queue[0] = XS.file('C:\\Users\\' + XCIP.uname + '\\Documents\\ipmsg.log', 'open');
		if (XCIP.queue[0]){
			if (XCIP.queue[0] != XCIP.queue[2]){
				XCIP.queue[2] = XCIP.queue[0];
				XCIP.queue[0] = XCIP.queue[0].split('=====================================');
				for (var i = 0; i <= XCIP.queue[0].length - 1; i++){
					XCIP.queue[0][i] = XCIP.queue[0][i].split('-------------------------------------');
				}
				for (var i = 0; i <= XCIP.queue[0].length - 1; i++){
					XCIP.queue[0][i][0] = XCIP.queue[0][i][0].split('(')[1];
				}
				for (var i = 1; i <= XCIP.queue[0].length - 1; i++){
					XCIP.queue[0][i][0] = XCIP.queue[0][i][0].split('/')[0];
				}
				XCIP.queue[1] = new Array();
				for (var i = 0; i <= XCIP.queue[0].length - 2; i++){
					XCIP.queue[1][i]    = new Array();
					XCIP.queue[1][i][0] = XCIP.queue[0][i + 1][0];
					XCIP.queue[1][i][1] = XCIP.queue[0][i + 1][1].split('\r\n')[1];
				}
				XCIP.queue[2] = XCIP.queue[1].copy();
			}
		}
	}
};

                         
var CAPICOM_STORE_OPEN_READ_ONLY = 0;
var CAPICOM_CURRENT_USER_STORE = 2;
var CAPICOM_CERTIFICATE_FIND_SHA1_HASH = 0;
var CAPICOM_CERTIFICATE_FIND_EXTENDED_PROPERTY = 6;
var CAPICOM_CERTIFICATE_FIND_TIME_VALID = 9;
var CAPICOM_CERTIFICATE_FIND_KEY_USAGE = 12;
var CAPICOM_DIGITAL_SIGNATURE_KEY_USAGE = 0x00000080;
var CAPICOM_AUTHENTICATED_ATTRIBUTE_SIGNING_TIME = 0;
var CAPICOM_INFO_SUBJECT_SIMPLE_NAME = 0;
var CAPICOM_E_CANCELLED = -2138568446;
var CERT_KEY_SPEC_PROP_ID = 6;                           
var CAPICOM_ENCRYPTION_ALGORITHM_RC2 = 0;
var CAPICOM_ENCRYPTION_ALGORITHM_RC4 = 1;
var CAPICOM_ENCRYPTION_ALGORITHM_DES = 2;
var CAPICOM_ENCRYPTION_ALGORITHM_3DES = 3;
var CAPICOM_ENCRYPTION_ALGORITHM_AES = 4;
var CAPICOM_ENCRYPTION_KEY_LENGTH_MAXIMUM = 0;
var CAPICOM_ENCRYPTION_KEY_LENGTH_40_BITS = 1;
var CAPICOM_ENCRYPTION_KEY_LENGTH_56_BITS = 2;
var CAPICOM_ENCRYPTION_KEY_LENGTH_128_BITS = 3; 
var CAPICOM_ENCRYPTION_KEY_LENGTH_192_BITS = 4; 
var CAPICOM_ENCRYPTION_KEY_LENGTH_256_BITS = 5; 
var CAPICOM_SECRET_PASSWORD = 0;
var CAPICOM_ENCODE_BASE64 = 0;
var CAPICOM_ENCODE_BINARY = 1;
var CAPICOM_ENCODE_ANY = -1;
var CAPI_ERROR = 0;
var XCap = {
	encrypt:function(idata, ipass, imode){
		var temp = 0;
		var EncryptedData = new ActiveXObject("CAPICOM.EncryptedData");
		EncryptedData.Algorithm.KeyLength = 0;
		EncryptedData.Algorithm.Name = imode;
		if (!imode){
			EncryptedData.Algorithm.Name = 4; 
		}
		EncryptedData.SetSecret(ipass, CAPICOM_SECRET_PASSWORD);
		EncryptedData.Content = idata;
		try{
			temp = EncryptedData.Encrypt(CAPICOM_ENCODE_BASE64);
			EncryptedData = null;
			return temp;
		}catch (e){
			alert(e.description);
			return false;
		}
	},
	decrypt:function(idata, ipass, imode){
		var temp = 0;
		var EncryptedData = new ActiveXObject("CAPICOM.EncryptedData");
		EncryptedData.SetSecret(ipass, CAPICOM_SECRET_PASSWORD);
		try{
			EncryptedData.Decrypt(idata);
			temp = EncryptedData.Content;
			EncryptedData = null;
			return temp;
		}catch (e){
			CAPI_ERROR = 1;
			if (e.description == 'Bad Data.\r\n'){
				alert('Invalid Credentials')
				window.close();
			}else{
				alert(e.description);
				return false;
			}
		}
	},
	chooseCert:function(){
		try{
			var MyStore = new ActiveXObject("CAPICOM.Store");
			MyStore.Open(CAPICOM_CURRENT_USER_STORE, "My", CAPICOM_STORE_OPEN_READ_ONLY);
			var FilteredCertificates = MyStore.Certificates.Find(CAPICOM_CERTIFICATE_FIND_SHA1_HASH, strUserCertificateThumbprint);
			var Signer = new ActiveXObject("CAPICOM.Signer");
			Signer.Certificate = FilteredCertificates.Item(1);
			return Signer;
			MyStore = null;
			FilteredCertificates = null;
		}catch (e){
			if (e.number != CAPICOM_E_CANCELLED){
				return new ActiveXObject("CAPICOM.Signer");
			}else{
				CAPI_ERROR = 1;
			}
		}
	},
	useCard:function(ihash){
		try{
			var SignedData = new ActiveXObject("CAPICOM.SignedData");
			SignedData.Content = ihash;
			var mdata = SignedData.Sign(XCap.chooseCert(), true, CAPICOM_ENCODE_BASE64);
			return mdata.slice(mdata.length-256, mdata.length);
		}catch (e){
			CAPI_ERROR = 1;
			alert(e.description);
			return false;
		}
	},
	thumbPrint:function(){
		try{
			var MyStore = new ActiveXObject("CAPICOM.Store");
			MyStore.Open(CAPICOM_CURRENT_USER_STORE, "My", CAPICOM_STORE_OPEN_READ_ONLY);
			return MyStore.Certificates(3).thumbprint; //1-3
		}catch (e){
			CAPI_ERROR = 1;
			alert(e.description);
			return false;
		}
	},
	example:function(){
		var temp = XCap.encrypt('test', XCap.useCard(prompt('Secret Phrase', ' ')), 4);
		alert(XCap.decrypt(temp, XCap.useCard(prompt('Secret Phrase', ' ')), 4));
	}
};